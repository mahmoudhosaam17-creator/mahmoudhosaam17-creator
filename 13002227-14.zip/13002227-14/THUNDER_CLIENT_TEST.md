# Thunder Client Testing Guide

## Step 1: Register a User (if needed)
**Method:** POST  
**URL:** `http://localhost:3000/api/v1/user`  
**Headers:**
```
Content-Type: application/json
```
**Body (JSON):**
```json
{
  "name": "Test Owner",
  "email": "owner@test.com",
  "password": "password123",
  "role": "truckOwner",
  "birthDate": "1990-01-01"
}
```

## Step 2: Login to Get Session Token
**Method:** POST  
**URL:** `http://localhost:3000/api/v1/user/login`  
**Headers:**
```
Content-Type: application/json
```
**Body (JSON):**
```json
{
  "email": "owner@test.com",
  "password": "password123"
}
```
**Response:** Copy the `token` value from the JSON response

## Step 3: Create a Menu Item (if needed)
**Method:** POST  
**URL:** `http://localhost:3000/api/v1/menuItem/new`  
**Headers:**
```
Content-Type: application/json
Cookie: session_token=YOUR_TOKEN_HERE
```
**Body (JSON):**
```json
{
  "name": "Test Burger",
  "price": 25.99,
  "category": "Main Course",
  "description": "A test burger"
}
```
**Response:** Note the itemId if you want to edit a specific item

## Step 4: Edit Menu Item
**Method:** PUT  
**URL:** `http://localhost:3000/api/v1/menuItem/edit/1`  
*(Replace 1 with your actual itemId)*

**Headers:**
```
Content-Type: application/json
Cookie: session_token=YOUR_TOKEN_HERE
```

**Body (JSON):**
```json
{
  "name": "Updated Burger Name",
  "price": 30.99,
  "category": "Main Course",
  "description": "Updated description"
}
```

**Expected Success Response:**
```json
{
  "message": "menu item updated successfully"
}
```

## Common Errors:
- **401 Unauthorized:** Missing or invalid session token
- **403 Unauthorized:** User doesn't have truckId (not a truck owner or no truck assigned)
- **404 Not Found:** Menu item doesn't exist or doesn't belong to your truck
- **400 Bad Request:** Invalid itemId or no fields provided to update

