// Quick script to check available trucks in the DB
const db = require('./connectors/db');

(async () => {
  try {
    const trucks = await db('FoodTruck.Trucks')
      .select('*')
      .where({ truckStatus: 'available', orderStatus: 'available' });
    console.log('Available trucks:', trucks);
    process.exit(0);
  } catch (err) {
    console.error('Error querying trucks:', err.message);
    process.exit(1);
  }
})();
