// Express route for owner dashboard API
const express = require('express');
const router = express.Router();
const db = require('../connectors/db');
const { getUser } = require('../utils/session');

// GET /api/v1/owner/dashboard
router.get('/dashboard', async (req, res) => {
  const user = await getUser(req);
  if (!user || user.role !== 'truckOwner' || !user.truckId) {
    return res.status(403).json({ message: 'Unauthorized' });
  }
  // Get truck info
  const truck = await db('FoodTruck.Trucks').where('truckId', user.truckId).first();
  // Menu items count
  const menuItems = await db('FoodTruck.MenuItems').where('truckId', user.truckId).count('itemId as count').first();
  // Pending/completed orders
  const pendingOrders = await db('FoodTruck.Orders').where({ truckId: user.truckId, orderStatus: 'pending' }).count('orderId as count').first();
  const completedOrders = await db('FoodTruck.Orders').where({ truckId: user.truckId, orderStatus: 'completed' }).count('orderId as count').first();
  // Recent orders (last 5)
  const recentOrders = await db('FoodTruck.Orders')
    .where('truckId', user.truckId)
    .orderBy('createdAt', 'desc')
    .limit(5)
    .select('orderId', 'orderStatus', 'totalPrice', 'createdAt');
  res.json({
    truckName: truck.truckName,
    truckStatus: truck.truckStatus,
    orderStatus: truck.orderStatus,
    menuItems: menuItems.count,
    pendingOrders: pendingOrders.count,
    completedOrders: completedOrders.count,
    recentOrders
  });
});

// PUT /api/v1/owner/orderStatus
router.put('/orderStatus', async (req, res) => {
  const user = await getUser(req);
  if (!user || user.role !== 'truckOwner' || !user.truckId) {
    return res.status(403).json({ message: 'Unauthorized' });
  }
  const { orderStatus } = req.body;
  await db('FoodTruck.Trucks').where('truckId', user.truckId).update({ orderStatus });
  res.json({ message: 'Order status updated' });
});

module.exports = router;
