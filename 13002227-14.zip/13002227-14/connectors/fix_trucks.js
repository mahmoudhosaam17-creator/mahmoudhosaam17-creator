const db = require('./db');

(async () => {
  try {
    // Set both statuses to 'available' for all trucks
    await db('FoodTruck.Trucks').update({ truckStatus: 'available', orderStatus: 'available' });
    // Add menu items for Burger Paradise (truckId: 2)
    await db('FoodTruck.MenuItems').insert([
      {
        truckId: 2,
        name: 'Classic Burger',
        description: 'Juicy beef patty with special sauce',
        price: 42.00,
        category: 'Main Course',
        status: 'available'
      },
      {
        truckId: 2,
        name: 'Cheese Fries',
        description: 'Fries topped with melted cheddar',
        price: 18.00,
        category: 'Sides',
        status: 'available'
      }
    ]);
    console.log('Updated truck statuses and added menu items for Burger Paradise.');
    process.exit(0);
  } catch (err) {
    console.error('Error updating trucks or menu items:', err);
    process.exit(1);
  }
})();
