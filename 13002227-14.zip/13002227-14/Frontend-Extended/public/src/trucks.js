$(document).ready(function () {

  $.ajax({
    url: '/api/v1/trucks/view',
    method: 'GET',
    success: function (trucks) {

      if (!trucks.length) {
        $('#noTrucksMsg').removeClass('d-none');
        return;
      }

      trucks.forEach(truck => {

        const logo = truck.truckLogo
          ? `<img src="${truck.truckLogo}" class="card-img-top" alt="Truck Logo">`
          : `<div class="text-center p-4">🚚</div>`;

        const truckCard = `
          <div class="col-md-4 mb-4">
            <div class="card">
              ${logo}
              <div class="card-body">
                <h5 class="card-title">${truck.truckName}</h5>
                <p class="card-text">Status: ${truck.truckStatus}</p>
                <a href="/truckMenu/${truck.truckId}" class="btn btn-primary">
                  View Menu
                </a>
              </div>
            </div>
          </div>
        `;

        $('#trucksContainer').append(truckCard);
      });
    },
    error: function () {
      alert('Failed to load trucks');
    }
  });

});