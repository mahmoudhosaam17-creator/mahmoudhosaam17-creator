const router = require('express').Router();

router.get('/trucks', (req, res) => {
  res.render('trucks');
});

module.exports = router;