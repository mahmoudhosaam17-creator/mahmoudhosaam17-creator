// ownerDashboard.js - owner overview
document.addEventListener('DOMContentLoaded', () => {
  console.log('ownerDashboard.js loaded');
});
