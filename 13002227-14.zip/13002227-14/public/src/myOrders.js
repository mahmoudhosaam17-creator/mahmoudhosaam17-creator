// myOrders.js - fetch and render user's orders
document.addEventListener('DOMContentLoaded', async () => {
  console.log('myOrders.js loaded');
  try {
    const res = await fetch('/api/v1/order/myOrders');
    const orders = await res.json();
    const el = document.getElementById('myOrders');
    if (!orders || orders.length === 0) el.textContent = 'No orders found';
    else el.innerHTML = orders.map(o => `<div>Order #${o.orderId} - ${o.orderStatus} - $${o.totalPrice}</div>`).join('');
  } catch (err) { console.error(err); }
});
