// menuItems.js - fetch and render owner's menu items
document.addEventListener('DOMContentLoaded', async () => {
  console.log('menuItems.js loaded');
  try {
    const res = await fetch('/api/v1/menuItem/view');
    const items = await res.json();
    const el = document.getElementById('menuItems');
    if (!items || items.length === 0) el.textContent = 'No menu items';
    else el.innerHTML = items.map(i => `<div>${i.name} - $${i.price}</div>`).join('');
  } catch (err) { console.error(err); }
});
