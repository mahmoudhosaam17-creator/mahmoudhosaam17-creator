// truckOrders.js - fetch orders for owner's truck
document.addEventListener('DOMContentLoaded', async () => {
  console.log('truckOrders.js loaded');
  try {
    const res = await fetch('/api/v1/order/truckOrders');
    const orders = await res.json();
    const el = document.getElementById('truckOrders');
    if (!orders || orders.length === 0) el.textContent = 'No orders';
    else el.innerHTML = orders.map(o => `<div>Order #${o.orderId} - ${o.customerName} - ${o.orderStatus}</div>`).join('');
  } catch (err) { console.error(err); }
});
