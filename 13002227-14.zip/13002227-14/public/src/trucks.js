// trucks.js (public/src/trucks.js)
console.log('✅ trucks.js loaded');

$(document).ready(function () {
  console.log('📡 Fetching trucks...');

  $.ajax({
    url: '/api/v1/trucks/view',
    method: 'GET',
    success: function (response) {
      console.log('✅ API response:', response);
      const trucks = response;
      const container = $('#trucksContainer');
      if (!trucks || trucks.length === 0) {
        container.html('<p>No trucks available right now.</p>');
        return;
      }
      let html = '';
      trucks.forEach(truck => {
        html += `
          <div class="card mb-3 col-md-6 col-lg-4">
            <div class="card-body">
              <img src="${truck.truckLogo || ''}" alt="Logo" style="max-width:80px;max-height:80px;float:right;">
              <h5 class="card-title">${truck.truckName}</h5>
              <p class="card-text">Truck ID: ${truck.truckId}</p>
              <p class="card-text">Status: ${truck.truckStatus}, Orders: ${truck.orderStatus}</p>
            </div>
          </div>
        `;
      });
      container.html(html);
    },
    error: function (err) {
      console.error('❌ API error:', err);
      $('#trucksContainer').html(
        '<p style="color:red;">Failed to load trucks.</p>'
      );
    }
  });
});
