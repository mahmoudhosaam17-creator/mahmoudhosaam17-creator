// myOrders.js - full order list UI
document.addEventListener('DOMContentLoaded', async () => {
  console.log('myOrders.js loaded');
  const ordersEl = document.getElementById('myOrders');
  let orders = [];

  function statusColor(status) {
    if (status === 'pending') return 'bg-warning';
    if (status === 'preparing') return 'bg-info';
    if (status === 'ready') return 'bg-success';
    if (status === 'completed') return 'bg-secondary';
    if (status === 'cancelled') return 'bg-danger';
    return 'bg-light';
  }

  async function fetchOrders() {
    const res = await fetch('/api/v1/order/myOrders');
    orders = await res.json();
    renderOrders();
  }

  function renderOrders() {
    if (!orders || orders.length === 0) {
      ordersEl.innerHTML = '<div class="alert alert-warning">No orders found.</div>';
      return;
    }
    ordersEl.innerHTML = `
      <div class="table-responsive">
        <table class="table align-middle table-hover order-table">
          <thead style="background:linear-gradient(90deg,#ff9800 0%,#00bcd4 100%);color:#fff;">
            <tr>
              <th>ID</th>
              <th>Truck</th>
              <th>Status</th>
              <th>Total</th>
              <th>Date</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            ${orders.map(o => `
              <tr class="order-row">
                <td><span class="fw-bold">${o.orderId}</span></td>
                <td>${o.truckName || ''}</td>
                <td><span class="badge ${statusColor(o.orderStatus)}" style="font-size:1em;">${o.orderStatus}</span></td>
                <td><span class="text-success fw-bold">$${o.totalPrice}</span></td>
                <td>${o.createdAt ? new Date(o.createdAt).toLocaleString() : ''}</td>
                <td><button class="btn btn-gradient btn-sm view-details" data-id="${o.orderId}" style="border-radius:12px;font-weight:600;">View Details</button></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
      <div id="orderDetails"></div>
      <style>
        .order-table tbody tr.order-row:hover {
          filter: brightness(0.96);
          background: #fffbe7;
          transition: background 0.18s, filter 0.18s;
        }
        .btn-gradient {
          background: linear-gradient(90deg,#ff9800,#00bcd4);
          color: #fff;
          border: none;
          transition: filter 0.18s;
        }
        .btn-gradient:hover {
          filter: brightness(1.13);
        }
      </style>
    `;
  }

  ordersEl.addEventListener('click', async (e) => {
    if (e.target.classList.contains('view-details')) {
      const orderId = e.target.getAttribute('data-id');
      const res = await fetch(`/api/v1/order/details/${orderId}`);
      const details = await res.json();
      document.getElementById('orderDetails').innerHTML = `
        <div class="card mt-3"><div class="card-body">
          <h5>Order #${details.orderId} Details</h5>
          <ul>${details.items.map(i => `<li>${i.itemName} x ${i.quantity} - $${i.price}</li>`).join('')}</ul>
        </div></div>
      `;
    }
  });

  fetchOrders();
});