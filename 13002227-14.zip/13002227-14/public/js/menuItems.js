

// Enhanced manage items page for owner dashboard
document.addEventListener('DOMContentLoaded', async () => {
  const menuEl = document.getElementById('menuItems');
  menuEl.innerHTML = 'Loading menu items...';

  // Modal helpers - using jQuery/Bootstrap 4 syntax
  function showModal(title, body, footer) {
    let modalEl = document.getElementById('itemModal');
    if (!modalEl) {
      const modalHtml = `
        <div id="itemModal" class="modal fade" tabindex="-1" role="dialog">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="itemModalTitle"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body" id="itemModalBody"></div>
              <div class="modal-footer" id="itemModalFooter"></div>
            </div>
          </div>
        </div>`;
      document.body.insertAdjacentHTML('beforeend', modalHtml);
      modalEl = document.getElementById('itemModal');
    }
    document.getElementById('itemModalTitle').innerHTML = title;
    document.getElementById('itemModalBody').innerHTML = body;
    document.getElementById('itemModalFooter').innerHTML = footer || '';
    // Use jQuery to show modal (Bootstrap 4)
    $(modalEl).modal('show');
  }

  async function fetchMenu() {
    try {
      // Add cache-busting parameter to ensure fresh data
      const res = await fetch(`/api/v1/menuItem/view?t=${Date.now()}`);
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to load menu items');
      }
      const items = await res.json();
      if (!Array.isArray(items)) {
        menuEl.innerHTML = '<div class="alert alert-danger">Invalid response from server</div>';
        return;
      }
      
      if (items.length === 0) {
        menuEl.innerHTML = '<div class="alert alert-warning">No menu items found.</div>';
        return;
      }
      menuEl.innerHTML = `
        <div class="table-responsive">
          <table class="table table-hover align-middle">
            <thead class="table-light">
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Description</th>
                <th>Price</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              ${items.map(i => `
                <tr>
                  <td>${i.itemId}</td>
                  <td>${i.name}</td>
                  <td>${i.category}</td>
                  <td>${i.description || ''}</td>
                  <td>$${parseFloat(i.price).toFixed(2)}</td>
                  <td><span class="badge ${i.status === 'available' ? 'bg-success' : 'bg-danger'}">${i.status}</span></td>
                  <td>
                    <button class="btn btn-outline-warning btn-sm edit-item me-1" data-id="${i.itemId}"><i class="bi bi-pencil"></i> Edit</button>
                    <button class="btn btn-outline-danger btn-sm delete-item" data-id="${i.itemId}"><i class="bi bi-trash"></i> Delete</button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    } catch (err) {
      console.error('Error fetching menu:', err);
      menuEl.innerHTML = `<div class="alert alert-danger">Could not load menu items. ${err.message}</div>`;
    }
  }

  menuEl.addEventListener('click', async (e) => {
    // Edit
    if (e.target.closest('.edit-item')) {
      const itemId = e.target.closest('.edit-item').getAttribute('data-id');
      try {
        const res = await fetch(`/api/v1/menuItem/view/${itemId}`);
        if (!res.ok) {
          const errorData = await res.json().catch(() => ({}));
          alert(errorData.message || 'Failed to load menu item');
          return;
        }
        const item = await res.json();
        showModal('Edit Menu Item', `
          <form id="editMenuItemForm">
            <div class="mb-2">
              <label class="form-label">Name</label>
              <input class="form-control" name="name" value="${(item.name || '').replace(/"/g, '&quot;')}" required />
            </div>
            <div class="mb-2">
              <label class="form-label">Category</label>
              <input class="form-control" name="category" value="${(item.category || '').replace(/"/g, '&quot;')}" required />
            </div>
            <div class="mb-2">
              <label class="form-label">Description</label>
              <textarea class="form-control" name="description" rows="2">${(item.description || '').replace(/"/g, '&quot;')}</textarea>
            </div>
            <div class="mb-2">
              <label class="form-label">Price</label>
              <input class="form-control" name="price" type="number" min="0" step="0.01" value="${item.price || 0}" required />
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
          </form>
        `);
      } catch (err) {
        console.error('Error loading menu item:', err);
        alert('Failed to load menu item details');
        return;
      }
      document.getElementById('editMenuItemForm').onsubmit = async (ev) => {
        ev.preventDefault();
        const form = ev.target;
        const body = {
          name: form.name.value.trim(),
          category: form.category.value.trim(),
          description: form.description.value.trim(),
          price: parseFloat(form.price.value)
        };
        
        // Validate price
        if (isNaN(body.price) || body.price < 0) {
          alert('Please enter a valid price');
          return;
        }
        
        try {
          console.log('Updating menu item:', itemId, body);
          const res = await fetch(`/api/v1/menuItem/edit/${itemId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            credentials: 'include'
          });
          
          console.log('Update response status:', res.status);
          const data = await res.json();
          console.log('Update response data:', data);
          
          if (!res.ok) {
            alert(data.message || `Failed to update menu item (${res.status})`);
            return;
          }
          
          // Success - hide modal first, then refresh
          $('#itemModal').modal('hide');
          
          // Refresh menu
          menuEl.innerHTML = 'Refreshing menu...';
          await fetchMenu();
          
          // Show success message after refresh
          setTimeout(() => {
            alert(data.message || 'Menu item updated successfully');
          }, 100);
        } catch (err) {
          console.error('Error updating menu item:', err);
          alert(`An error occurred: ${err.message}`);
        }
      };
      return;
    }
    // Delete
    if (e.target.closest('.delete-item')) {
      const itemId = e.target.closest('.delete-item').getAttribute('data-id');
      showModal('Delete Menu Item', '<div class="text-danger">Are you sure you want to delete this menu item?</div>', `
        <button type="button" class="btn btn-secondary" id="cancelDeleteBtn">Cancel</button>
        <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
      `);
      // Attach handlers after modal is shown
      const modalEl = document.getElementById('itemModal');
      $(modalEl).one('shown.bs.modal', function () {
        const cancelBtn = document.getElementById('cancelDeleteBtn');
        const confirmBtn = document.getElementById('confirmDelete');
        if (cancelBtn) {
          cancelBtn.onclick = () => {
            $(modalEl).modal('hide');
          };
        }
        if (confirmBtn) {
          confirmBtn.onclick = async () => {
            try {
              console.log('Deleting menu item:', itemId);
              const res = await fetch(`/api/v1/menuItem/delete/${itemId}`, { 
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include'
              });
              
              console.log('Delete response status:', res.status);
              const data = await res.json();
              console.log('Delete response data:', data);
              
              if (!res.ok) {
                alert(data.message || `Failed to delete menu item (${res.status})`);
                return;
              }
              
              // Success - hide modal first, then refresh
              $(modalEl).modal('hide');
              
              // Refresh menu
              menuEl.innerHTML = 'Refreshing menu...';
              await fetchMenu();
              
              // Show success message after refresh
              setTimeout(() => {
                alert(data.message || 'Menu item deleted successfully');
              }, 100);
            } catch (err) {
              console.error('Error deleting menu item:', err);
              alert(`An error occurred: ${err.message}`);
            }
          };
        }
      });
      return;
    }
  });

  await fetchMenu();
});