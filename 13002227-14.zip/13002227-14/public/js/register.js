// Registration logic for register page
$(document).ready(function() {
	$('#registerBtn').on('click', async function() {
		// Clear previous errors
		$('#errorMsg').hide().text('');
		$('.text-danger').hide().text('');

		const name = $('#name').val().trim();
		const birthDate = $('#birthDate').val();
		const email = $('#email').val().trim();
		const password = $('#password').val();

		let hasError = false;
		if (!name) {
			$('#nameError').show().text('Name is required.');
			hasError = true;
		}
		if (!birthDate) {
			$('#birthDateError').show().text('Birth date is required.');
			hasError = true;
		}
		if (!email) {
			$('#emailError').show().text('Email is required.');
			hasError = true;
		}
		if (!password) {
			$('#passwordError').show().text('Password is required.');
			hasError = true;
		}
		if (hasError) return;

		try {
			const response = await fetch('/api/v1/user', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ name, birthDate, email, password, role: 'customer' })
			});
			if (response.ok) {
				// Auto-login after registration
				const loginResp = await fetch('/api/v1/user/login', {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ email, password })
				});
				if (loginResp.ok) {
					window.location.href = '/dashboard';
				} else {
					window.location.href = '/';
				}
			} else {
				let errorMsg = 'Registration failed.';
				try {
					const data = await response.json();
					errorMsg = data.message || errorMsg;
				} catch (e) {
					const text = await response.text();
					if (text) errorMsg = text;
				}
				$('#errorMsg').show().text(errorMsg);
			}
		} catch (err) {
			$('#errorMsg').show().text('Network error. Please try again.');
		}
	});
});