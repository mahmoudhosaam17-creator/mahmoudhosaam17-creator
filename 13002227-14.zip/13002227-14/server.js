const express = require('express');
const app = express();
const bodyParser = require("body-parser");
const {handlePrivateBackendApi} = require('./routes/private/api');
const {handlePublicBackendApi} = require('./routes/public/api');
const {handlePublicFrontEndView} = require('./routes/public/view');
const {handlePrivateFrontEndView} = require('./routes/private/view');
const {authMiddleware} = require('./middleware/auth');
const handleLogout = require('./routes/public/logout');
const db = require('./connectors/db');
const ownerDashboardApi = require('./routes/ownerDashboardApi');
require('dotenv').config();
const PORT = process.env.PORT || 3000;


// view engine setup
app.set('views', './views');
app.set('view engine', 'hjs');
app.use(express.static('./public'));

// Handle post requests
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true}));



handlePublicFrontEndView(app);
handlePublicBackendApi(app);
handleLogout(app);
app.use('/api/v1/owner', ownerDashboardApi);
app.use(authMiddleware);
handlePrivateFrontEndView(app);
handlePrivateBackendApi(app);

async function startServer() {
    try {
        // Check DB connectivity before starting
        await db.raw('select 1+1 as result');
    } catch (err) {
        console.error('Database connection failed. Please check your DB settings in connectors/db.js and .env');
        console.error(err && err.message ? err.message : err);
        process.exit(1);
    }

    const server = app.listen(PORT, () => {
        console.log(`Server is now listening at port ${PORT} on http://localhost:${PORT}/`);
    });

    server.on('error', (err) => {
        if (err && err.code === 'EADDRINUSE') {
            console.error(`Port ${PORT} is already in use. Kill the process using that port or set PORT env variable.`);
        } else {
            console.error('Server error:', err);
        }
        process.exit(1);
    });

    // Graceful shutdown
    process.on('SIGINT', async () => {
        console.log('Received SIGINT, shutting down...');
        server.close(async () => {
            try { await db.destroy(); } catch (e) { }
            process.exit(0);
        });
    });
}

startServer();










