const db = require('../connectors/db');
const { getSessionToken } = require('../utils/session');

async function authMiddleware(req, res, next) {
  try {
    const sessionToken = getSessionToken(req);

    // 1️⃣ No token
    if (!sessionToken) {
      // If the request expects JSON (API) respond with 401 JSON,
      // otherwise redirect to the login page for frontend view requests.
      const wantsJson = req.path.startsWith('/api') || (req.headers.accept && req.headers.accept.includes('application/json')) || req.xhr;
      if (wantsJson) {
        return res.status(401).json({ message: 'Unauthorized: session token missing' });
      }
      return res.redirect('/');
    }

    // 2️⃣ Token not found
    const userSession = await db('FoodTruck.Sessions')
      .where({ token: sessionToken })
      .first();

    if (!userSession) {
      const wantsJson = req.path.startsWith('/api') || (req.headers.accept && req.headers.accept.includes('application/json')) || req.xhr;
      if (wantsJson) {
        return res.status(401).json({ message: 'Unauthorized: invalid session' });
      }
      return res.redirect('/');
    }

    // 3️⃣ Token expired
    if (new Date() > new Date(userSession.expiresAt)) {
      const wantsJson = req.path.startsWith('/api') || (req.headers.accept && req.headers.accept.includes('application/json')) || req.xhr;
      if (wantsJson) {
        return res.status(401).json({ message: 'Unauthorized: session expired' });
      }
      return res.redirect('/');
    }

    // ✅ Auth OK
    next();

  } catch (err) {
    console.error(err);
    const wantsJson = req.path.startsWith('/api') || (req.headers.accept && req.headers.accept.includes('application/json')) || req.xhr;
    if (wantsJson) {
      return res.status(500).json({ message: 'Authentication error' });
    }
    return res.redirect('/');
  }
}

module.exports = { authMiddleware };



