// Utility to clear the session cookie and redirect to login
module.exports = function handleLogout(app) {
  app.get('/logout', (req, res) => {
    res.clearCookie('session_token');
    res.redirect('/');
  });
};
