

const { getUser } = require('../../utils/session');

function handlePublicFrontEndView(app) {
  // Root route: if logged in, redirect to dashboard, else show login
  app.get('/', async function(req, res) {
    const user = await getUser(req);
    if (user) {
      return res.redirect('/dashboard');
    } else {
      return res.render('login');
    }
  });

  app.get('/register', async function(req, res) {
    return res.render('register');
  });

  // Dashboard route (simple placeholder)
  app.get('/dashboard', async function(req, res) {
    const user = await getUser(req);
    if (!user) {
      return res.redirect('/');
    }
    if (user.role === 'truckOwner') {
      return res.render('ownerDashboard', { user });
    } else {
      // Add flags for Hogan.js conditional rendering
      let isTruckOwner = false, isCustomer = false;
      if (user && user.role === 'truckOwner') isTruckOwner = true;
      if (user && user.role === 'customer') isCustomer = true;

      // Check if any truck is available for orders
      const db = require('../../connectors/db');
      let orderAvailable = true;
      const truck = await db('FoodTruck.Trucks').where('truckStatus', 'active').andWhere('orderStatus', 'available').first();
      if (!truck) orderAvailable = false;

      return res.render('dashboard', { user, isTruckOwner, isCustomer, orderAvailable });
    }
  });
}

module.exports = {handlePublicFrontEndView};
  