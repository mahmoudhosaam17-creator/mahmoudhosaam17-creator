const { v4 } = require('uuid');
const db = require('../../connectors/db');
const axios = require('axios');

function handlePublicBackendApi(app) {

    // Register HTTP endpoint to create new user
    app.post('/api/v1/user', async function(req, res) {
      // Basic validation: require email in request body
      const { email } = req.body || {};
      if (!email) {
        return res.status(400).send('email is required');
      }

      // Check if user already exists in the system
      const userExists = await db.select('*').from('FoodTruck.Users').where('email', email);
      //console.log(userExists)
      if (userExists.length > 0) {
        return res.status(400).send('user exists');
      }
      
      try {
        const newUser = req.body;
        const user = await db('FoodTruck.Users').insert(newUser).returning('*');
        return res.status(200).json(user);
      } catch (e) {
        console.log(e.message);
        return res.status(400).send('Could not register user');
      }
    });

    // Register HTTP endpoint to create new user
    app.post('/api/v1/user/login', async function(req, res) {
      // get users credentials from the JSON body
      const { email, password } = req.body
      if (!email) {
        // If the email is not present, return an HTTP unauthorized code
        return res.status(400).send('email is required');
      }
      if (!password) {
        // If the password is not present, return an HTTP unauthorized code
        return res.status(400).send('Password is required');
      }

      // validate the provided password against the password in the database
      // if invalid, send an unauthorized code
      let user = await db.select('*').from('FoodTruck.Users').where('email', email);
      if (user.length == 0) {
        return res.status(400).send('user does not exist');
      }
      user = user[0];
      if (user.password !== password) {
        return res.status(400).send('Password does not match');
      }

      // set the expiry time as 30 minutes after the current time
      const token = v4();
      const currentDateTime = new Date();
      const expiresAt = new Date(+currentDateTime + 18000000); // expire in 3 minutes

      // create a session containing information about the user and expiry time
      const session = {
        userId: user.userId,
        token,
        expiresAt,
      };
      try {
        await db('FoodTruck.Sessions').insert(session);
        // In the response, set a cookie on the client with the name "session_cookie"
        // and the value as the UUID we generated. We also set the expiration time.
        axios.defaults.headers.common['Cookie'] = `session_token=${token};expires=${expiresAt}`;
        return res.cookie("session_token", token, { expires: expiresAt }).status(200).json({
          message: 'login successful',
          token: token  // Return token in response body for API clients like Thunder Client
        });
      } catch (e) {
        console.log(e.message);
        return res.status(400).send('Could not register user');
      }
    });

    // Public endpoint: Get menu items for a specific truck
    // GET /api/v1/menuItem/truck/:truckId
    app.get('/api/v1/menuItem/truck/:truckId', async (req, res) => {
      try {
        const { truckId } = req.params;
        const menuItems = await db('FoodTruck.MenuItems')
          .select(
            'itemId',
            'truckId',
            'name',
            'description',
            'price',
            'category',
            'status',
            'createdAt'
          )
          .where({
            truckId: truckId,
            status: 'available'
          })
          .orderBy('itemId', 'asc');
        return res.status(200).json(menuItems);
      } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Internal server error' });
      }
    });

};


module.exports = {handlePublicBackendApi};
