// customerHomepage.js - handle logout and small UI behaviors
document.addEventListener('DOMContentLoaded', () => {
  const logoutBtn = document.getElementById('logoutBtn');
  if (!logoutBtn) return;
  logoutBtn.addEventListener('click', (e) => {
    e.preventDefault();
    // Redirect to logout route which clears session and redirects to login
    window.location.href = '/logout';
  });
});
