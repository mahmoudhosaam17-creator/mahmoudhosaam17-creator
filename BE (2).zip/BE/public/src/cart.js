// cart.js - fetch and render cart items
document.addEventListener('DOMContentLoaded', async () => {
  console.log('cart.js loaded');
  try {
    const res = await fetch('/api/v1/cart/view');
    const items = await res.json();
    const el = document.getElementById('cartItems');
    if (!items || items.length === 0) el.textContent = 'Cart is empty';
    else el.innerHTML = items.map(i => `<div>${i.itemName} x ${i.quantity} - $${i.price}</div>`).join('');
  } catch (err) { console.error(err); }
});
