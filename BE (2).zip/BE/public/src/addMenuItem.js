// addMenuItem.js - submit new menu item
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('addMenuItemForm');
  if (!form) return;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = new FormData(form);
    const payload = {
      name: data.get('name'),
      price: parseFloat(data.get('price')),
      category: data.get('category'),
      description: data.get('description')
    };
    try {
      const res = await fetch('/api/v1/menuItem/new', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
      });
      const json = await res.json();
      alert(json.message || 'done');
    } catch (err) { console.error(err); }
  });
});
