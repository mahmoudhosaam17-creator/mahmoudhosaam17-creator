document.addEventListener('DOMContentLoaded', () => {
  const registerBtn = document.getElementById('registerBtn');
  const nameEl = document.getElementById('name');
  const birthEl = document.getElementById('birthDate');
  const emailEl = document.getElementById('email');
  const passEl = document.getElementById('password');
  const errorMsg = document.getElementById('errorMsg');
  const nameError = document.getElementById('nameError');
  const birthError = document.getElementById('birthDateError');
  const emailError = document.getElementById('emailError');
  const passError = document.getElementById('passwordError');

  function clearErrors() {
    if (errorMsg) { errorMsg.style.display = 'none'; errorMsg.textContent = ''; }
    [nameError, birthError, emailError, passError].forEach(el => { if (el) { el.style.display = 'none'; el.textContent = ''; } });
  }

  async function handleRegister() {
    clearErrors();
    const name = nameEl.value && nameEl.value.trim();
    const birthDate = birthEl.value && birthEl.value.trim();
    const email = emailEl.value && emailEl.value.trim();
    const password = passEl.value && passEl.value.trim();

    let hasError = false;
    if (!name) { nameError.textContent = 'Name is required'; nameError.style.display = 'block'; hasError = true; }
    if (!birthDate) { birthError.textContent = 'Birth date is required'; birthError.style.display = 'block'; hasError = true; }
    if (!email) { emailError.textContent = 'Email is required'; emailError.style.display = 'block'; hasError = true; }
    if (!password) { passError.textContent = 'Password is required'; passError.style.display = 'block'; hasError = true; }
    if (hasError) return;

    registerBtn.disabled = true;
    registerBtn.textContent = 'Registering...';

    try {
      const res = await fetch('/api/v4/user' /* fallback: some setups may use v4, try main endpoint next */ , {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, email, birthDate, password })
      });

      // some servers return plain text on error; try to read text and parse
      const text = await res.text();
      let data;
      try { data = JSON.parse(text); } catch (e) { data = null; }

      if (res.ok) {
        window.location.href = '/';
        return;
      }

      const serverMessage = text || (data && data.message) || 'Registration failed';
      if (errorMsg) { errorMsg.textContent = serverMessage; errorMsg.style.display = 'block'; }

    } catch (err) {
      if (errorMsg) { errorMsg.textContent = err.message || 'Network error'; errorMsg.style.display = 'block'; }
    } finally {
      registerBtn.disabled = false;
      registerBtn.textContent = 'Register';
    }
  }

  // try primary correct endpoint and fallback to /api/v1/user if 404
  if (registerBtn) registerBtn.addEventListener('click', async () => {
    // attempt primary POST endpoint
    try {
      await handleRegister();
    } catch (e) {
      // no-op, errors shown inside handleRegister
    }
  });

  const form = document.getElementById('registerForm');
  if (form) form.addEventListener('submit', (e) => { e.preventDefault(); handleRegister(); });
});