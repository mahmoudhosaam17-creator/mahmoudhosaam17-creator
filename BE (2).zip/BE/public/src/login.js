$(document).ready(function () {

  $('#loginForm').on('submit', function (e) {
    e.preventDefault();

    const email = $('#email').val().trim();
    const password = $('#password').val().trim();

    if (!email || !password) {
      $('#error').removeClass('d-none').text('Please fill all fields');
      return;
    }

    $.ajax({
      url: '/api/v1/user/login',
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({ email, password }),

      success: function (res) {
        localStorage.setItem('token', res.token);
        window.location.href = '/dashboard';
      },

      error: function (err) {
        $('#error')
          .removeClass('d-none')
          .text(err.responseJSON?.message || 'Login failed');
      }
    });
  });

});document.addEventListener('DOMContentLoaded', () => {
  const submitBtn = document.getElementById('loginBtn');
  const emailEl = document.getElementById('email');
  const passEl = document.getElementById('password');
  const errorContainer = document.getElementById('error');

  console.log('login.js loaded', { submitBtn: !!submitBtn, email: !!emailEl, password: !!passEl });

  function clearErrors() {
    if (errorContainer) {
      errorContainer.classList.add('d-none');
      errorContainer.textContent = '';
    }
  }

  async function handleLogin() {
    clearErrors();
    const email = emailEl.value && emailEl.value.trim();
    const password = passEl.value && passEl.value.trim();

    let hasError = false;
    if (!email) {
      if (errorContainer) errorContainer.textContent = 'Email is required';
      hasError = true;
    }
    if (!password) {
      if (errorContainer && !hasError) errorContainer.textContent = 'Password is required';
      else if (errorContainer) errorContainer.textContent = errorContainer.textContent + ' Password is required';
      hasError = true;
    }
    if (hasError) { if (errorContainer) errorContainer.classList.remove('d-none'); return; }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Logging in...';

    try {
      const res = await fetch('/api/v1/user/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      const text = await res.text();
      console.log('login response', res.status, text);
      if (res.ok) {
        window.location.href = '/dashboard';
        return;
      }
      if (errorContainer) { errorContainer.textContent = text || 'Login failed'; errorContainer.classList.remove('d-none'); }

    } catch (err) {
      if (errorContainer) { errorContainer.textContent = err.message || 'Network error'; errorContainer.classList.remove('d-none'); }
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Login';
    }
  }

  if (submitBtn) submitBtn.addEventListener('click', handleLogin);
  // allow pressing Enter inside form (if a form wrapper exists)
  const form = document.getElementById('loginForm');
  if (form) form.addEventListener('submit', (e) => { e.preventDefault(); handleLogin(); });
});