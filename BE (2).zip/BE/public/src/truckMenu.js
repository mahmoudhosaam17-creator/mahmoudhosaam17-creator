// truckMenu.js - fetch and render menu items for a truck
document.addEventListener('DOMContentLoaded', async () => {
  console.log('truckMenu.js loaded');
  const menuEl = document.getElementById('truckMenu');
  const truckId = menuEl ? menuEl.getAttribute('data-truck-id') : null;
  if (!truckId) return;

  let allItems = [];
  let categories = [];

  function renderMenu(items) {
    if (!items.length) {
      menuEl.innerHTML = '<div class="alert alert-warning">No menu items available.</div>';
      return;
    }
    menuEl.innerHTML = items.map(i => `
      <div class="card mb-2">
        <div class="card-body">
          <h5>${i.name} <span class="badge bg-secondary">${i.category}</span></h5>
          <p>${i.description || ''}</p>
          <div>Price: $${i.price}</div>
          <div class="input-group mb-2" style="max-width:140px;">
            <input type="number" min="1" value="1" class="form-control qty-input" data-id="${i.itemId}" style="width:60px;">
            <button class="btn btn-success add-to-cart" data-id="${i.itemId}">Add to Cart</button>
          </div>
        </div>
      </div>
    `).join('');
  }

  function renderCategories() {
    if (!categories.length) return '';
    return `<div class="mb-3"><label>Filter by Category: </label> <select id="categoryFilter"><option value="">All</option>${categories.map(c => `<option value="${c}">${c}</option>`)}</select></div>`;
  }

  async function fetchMenu(category) {
    let url = category ? `/api/v1/menuItem/truck/${truckId}/category/${encodeURIComponent(category)}` : `/api/v1/menuItem/truck/${truckId}`;
    const res = await fetch(url);
    const items = await res.json();
    return items;
  }

  async function init() {
    allItems = await fetchMenu();
    categories = [...new Set(allItems.map(i => i.category))];
    menuEl.insertAdjacentHTML('beforebegin', renderCategories());
    renderMenu(allItems);
  }

  await init();

  // Category filter
  document.body.addEventListener('change', async (e) => {
    if (e.target && e.target.id === 'categoryFilter') {
      const cat = e.target.value;
      const items = cat ? await fetchMenu(cat) : allItems;
      renderMenu(items);
    }
  });

  // Add to cart
  menuEl.addEventListener('click', async (e) => {
    if (e.target && e.target.classList.contains('add-to-cart')) {
      const itemId = e.target.getAttribute('data-id');
      const qtyInput = menuEl.querySelector(`.qty-input[data-id="${itemId}"]`);
      const quantity = qtyInput ? parseInt(qtyInput.value, 10) : 1;
      try {
        const res = await fetch('/api/v1/cart/new', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ itemId, quantity })
        });
        if (res.ok) {
          e.target.textContent = 'Added!';
          setTimeout(() => { e.target.textContent = 'Add to Cart'; }, 1200);
        } else {
          alert('Failed to add to cart');
        }
      } catch (err) {
        alert('Error adding to cart');
      }
    }
  });
});
