// Truck orders management for owner - full requirements
document.addEventListener('DOMContentLoaded', async () => {
	const ordersEl = document.getElementById('truckOrders');
	let orders = [];
	let filter = 'all';
	const statusList = ['pending', 'preparing', 'ready', 'completed', 'cancelled'];

	function showLoading() {
		ordersEl.innerHTML = `<div class="d-flex justify-content-center align-items-center" style="height:120px;">
			<div class="spinner-border text-primary" style="width:3rem;height:3rem;" role="status">
				<span class="visually-hidden">Loading...</span>
			</div>
		</div>`;
	}

	async function fetchOrders() {
		showLoading();
		try {
			const res = await fetch('/api/v1/order/truckOrders');
			if (!res.ok) throw new Error('Failed to load orders');
			orders = await res.json();
			if (!Array.isArray(orders)) orders = [];
		} catch (err) {
			orders = [];
		}
		renderOrders();
	}

	function statusColor(status) {
		if (status === 'pending') return 'bg-warning';
		if (status === 'preparing') return 'bg-info';
		if (status === 'ready') return 'bg-success';
		if (status === 'completed') return 'bg-secondary';
		if (status === 'cancelled') return 'bg-danger';
		return 'bg-light';
	}

	function renderOrders() {
		// Vertical filter tabs in boxes with colored dots
		const statusColors = {
			all: '#888',
			pending: '#ffc107',
			preparing: '#17a2b8',
			ready: '#4caf50',
			completed: '#6c757d',
			cancelled: '#dc3545'
		};
		let tabs = `<div class="horizontal-tabs mb-4">
			${['all', ...statusList].map(s => `
				<div class="tab-box${filter === s ? ' active' : ''}" data-filter="${s}">
					<span class="dot" style="background:${statusColors[s]};"></span>
					<span class="tab-label">${s.charAt(0).toUpperCase() + s.slice(1)}</span>
				</div>
			`).join('')}
		</div>`;

		let filtered = filter==='all' ? orders : orders.filter(o => o.orderStatus === filter);
		if (!filtered || filtered.length === 0) {
			ordersEl.innerHTML = tabs + '<div class="alert alert-warning">No orders found.</div>';
			return;
		}
		ordersEl.innerHTML = tabs + `
			<div class="table-responsive">
				<table class="table table-hover align-middle">
					<thead class="table-light">
						<tr>
							<th>ID</th>
							<th>Customer</th>
							<th>Status</th>
							<th>Total</th>
							<th>Pickup Time</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody>
						${filtered.map(o => `
							<tr>
								<td>${o.orderId}</td>
								<td>${o.customerName || ''}</td>
								<td><span class="badge ${statusColor(o.orderStatus)}">${o.orderStatus}</span></td>
								<td>$${o.totalPrice}</td>
								<td>${o.scheduledPickupTime ? new Date(o.scheduledPickupTime).toLocaleString() : ''}</td>
								<td>
									<button class="btn btn-outline-info btn-sm view-details me-1" data-id="${o.orderId}"><i class="bi bi-eye"></i> View</button>
									<select class="form-select form-select-sm d-inline w-auto status-dropdown" data-id="${o.orderId}" style="min-width:110px;">
										${statusList.map(s => `<option value="${s}"${o.orderStatus===s?' selected':''}>${s.charAt(0).toUpperCase()+s.slice(1)}</option>`).join('')}
									</select>
									<button class="btn btn-outline-success btn-sm update-status ms-1" data-id="${o.orderId}">Update Status</button>
								</td>
							</tr>
						`).join('')}
					</tbody>
				</table>
			</div>
			<div id="orderDetails"></div>
		`;
	}

	ordersEl.onclick = async (e) => {
		// Filter tab click (vertical)
		if (e.target.closest('.tab-box')) {
			filter = e.target.closest('.tab-box').getAttribute('data-filter');
			renderOrders();
			return;
		}
		// View details
		if (e.target.closest('.view-details')) {
			const orderId = e.target.closest('.view-details').getAttribute('data-id');
			const res = await fetch(`/api/v1/order/truckOwner/${orderId}`);
			const details = await res.json();
			document.getElementById('orderDetails').innerHTML = `
				<div class="card mt-3"><div class="card-body">
					<h5>Order #${details.orderId} Details</h5>
					<ul>${details.items.map(i => `<li>${i.itemName} x ${i.quantity} - $${i.price}</li>`).join('')}</ul>
				</div></div>
			`;
			return;
		}
		// Update status
		if (e.target.closest('.update-status')) {
			const orderId = e.target.closest('.update-status').getAttribute('data-id');
			const select = document.querySelector(`.status-dropdown[data-id="${orderId}"]`);
			const newStatus = select.value;
			await fetch(`/api/v1/order/updateStatus/${orderId}`, {
				method: 'PUT',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ orderStatus: newStatus })
			});
			await fetchOrders();
			return;
		}
	};

	await fetchOrders();
});