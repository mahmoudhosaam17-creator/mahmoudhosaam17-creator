// Proxy to src/customerHomepage.js
import('../src/customerHomepage.js');