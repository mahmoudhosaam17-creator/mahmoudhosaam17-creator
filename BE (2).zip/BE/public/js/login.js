// Login logic for login page
$(document).ready(function() {
	$('#loginBtn').on('click', async function() {
		const email = $('#email').val();
		const password = $('#password').val();
		$('#error').addClass('d-none').text('');

		if (!email || !password) {
			$('#error').removeClass('d-none').text('Please enter both email and password.');
			return;
		}

		try {
			const response = await fetch('/api/v1/user/login', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({ email, password })
			});

			if (response.ok) {
				// Redirect to homepage or dashboard on success
				window.location.href = '/';
			} else {
				let errorMsg = 'Login failed.';
				try {
					// Try to parse JSON error
					const data = await response.json();
					errorMsg = data.message || errorMsg;
				} catch (e) {
					// Fallback to plain text error
					const text = await response.text();
					if (text) errorMsg = text;
				}
				$('#error').removeClass('d-none').text(errorMsg);
			}
		} catch (err) {
			$('#error').removeClass('d-none').text('Network error. Please try again.');
		}
	});
});