

$(document).ready(function () {
  var truckId = $('#truckMenu').data('truck-id');
  console.log('DEBUG truckId:', truckId);
  var $menuGrid = $('#menuItemsGrid');
  $menuGrid.html('Loading menu...');
  $.ajax({
    url: '/api/v1/menuItem/truck/' + truckId,
    method: 'GET',
    success: function (items) {
      if (!items.length) {
        $menuGrid.html('<div class="alert alert-warning">No menu items available.</div>');
        return;
      }
        var html = items.map(function(item) {
          return `
            <div class="menu-card">
              <div class="menu-img">🍔</div>
              <div class="menu-name">${item.name}</div>
              <div class="menu-desc">${item.description || ''}</div>
              <div class="menu-price">$${item.price}</div>
              <button class="btn btn-success add-to-cart-btn" data-id="${item.itemId}" data-price="${item.price}">Add to Cart</button>
              <div class="cart-feedback" id="cart-feedback-${item.itemId}" style="display:none;color:#388e3c;font-weight:600;margin-top:0.7rem;">Added to cart!</div>
            </div>
          `;
        }).join('');
        $menuGrid.html(html);

        // Attach click handler for Add to Cart buttons
        $menuGrid.find('.add-to-cart-btn').click(function () {
          var itemId = $(this).data('id');
          var price = $(this).data('price');
          var $feedback = $('#cart-feedback-' + itemId);
          $.ajax({
            url: '/api/v1/cart/new',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ itemId: itemId, quantity: 1, price: price }),
            success: function () {
              $feedback.text('Added to cart!').css('color', '#388e3c').show().delay(1200).fadeOut();
            },
            error: function () {
              $feedback.text('Error adding to cart!').css('color', '#d32f2f').show().delay(1200).fadeOut(function(){
                $(this).text('Added to cart!').css('color', '#388e3c');
              });
            }
          });
        });
    },
    error: function () {
      $menuGrid.html('<div class="alert alert-danger">Error loading menu.</div>');
    }
  });
});