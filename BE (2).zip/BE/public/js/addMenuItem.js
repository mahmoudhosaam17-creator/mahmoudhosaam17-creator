// Add Menu Item Page logic
document.addEventListener('DOMContentLoaded', () => {
	const form = document.getElementById('addMenuItemForm');
	const name = document.getElementById('name');
	const category = document.getElementById('category');
	const description = document.getElementById('description');
	const price = document.getElementById('price');
	const msgBox = document.createElement('div');
	form.parentNode.insertBefore(msgBox, form);

	// Cancel button
	let cancelBtn = document.getElementById('cancelAddMenuItem');
	if (!cancelBtn) {
		cancelBtn = document.createElement('button');
		cancelBtn.type = 'button';
		cancelBtn.className = 'btn btn-secondary mt-2';
		cancelBtn.id = 'cancelAddMenuItem';
		cancelBtn.textContent = 'Cancel';
		form.appendChild(cancelBtn);
	}
	cancelBtn.onclick = () => {
		window.location.href = '/menuItems';
	};

	form.onsubmit = async (e) => {
		e.preventDefault();
		msgBox.innerHTML = '';
		// Validation
		if (!name.value.trim() || !category.value.trim() || !price.value.trim()) {
			msgBox.innerHTML = '<div class="alert alert-danger">Name, Category, and Price are required.</div>';
			return;
		}
		if (isNaN(price.value) || Number(price.value) <= 0) {
			msgBox.innerHTML = '<div class="alert alert-danger">Price must be a positive number.</div>';
			return;
		}
		// Submit
		const body = {
			name: name.value.trim(),
			category: category.value.trim(),
			description: description.value.trim(),
			price: parseFloat(price.value)
		};
		const res = await fetch('/api/v1/menuItem/new', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(body)
		});
		if (res.ok) {
			msgBox.innerHTML = '<div class="alert alert-success">Menu item added successfully! Redirecting...</div>';
			setTimeout(() => {
				window.location.href = '/menuItems';
			}, 1200);
		} else {
			const err = await res.json();
			msgBox.innerHTML = `<div class="alert alert-danger">${err.message || 'Failed to add menu item.'}</div>`;
		}
	};
});