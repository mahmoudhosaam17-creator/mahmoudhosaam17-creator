// trucks.js
console.log('✅ trucks.js loaded');


function fetchAndRenderTrucks() {
  console.log('📡 Fetching trucks...');
  $.ajax({
    url: '/api/v1/trucks/view',
    method: 'GET',
    success: function (response) {
      console.log('✅ API response:', response);
      const trucks = response;
      const container = $('#trucksContainer');
      const noTrucksMsg = $('#noTrucksMsg');
      if (!trucks || trucks.length === 0) {
        container.html('');
        noTrucksMsg.show();
        return;
      }
      noTrucksMsg.hide();
      let html = '';
      trucks.forEach(truck => {
        const logo = truck.truckLogo && truck.truckLogo.startsWith('http') ? truck.truckLogo : 'https://via.placeholder.com/80?text=No+Logo';
        html += `
          <div class="card mb-3 col-md-6 col-lg-4">
            <div class="card-body">
              <img src="${logo}" alt="Logo" style="max-width:80px;max-height:80px;float:right;">
              <h5 class="card-title">${truck.truckName}</h5>
              <p class="card-text">Truck ID: ${truck.truckId}</p>
              <p class="card-text">Status: ${truck.truckStatus}, Orders: ${truck.orderStatus}</p>
              <a href="/truckMenu/${truck.truckId}" class="btn btn-primary mt-2">View Menu</a>
            </div>
          </div>
        `;
      });
      container.html(html);
    },
    error: function (err) {
      console.error('❌ API error:', err);
      $('#trucksContainer').html(
        '<p style="color:red;">Failed to load trucks.</p>'
      );
    }
  });
}

$(document).ready(function () {
  fetchAndRenderTrucks();
  setInterval(fetchAndRenderTrucks, 10000); // Refresh every 10 seconds
});