// cart.js - full cart UI
document.addEventListener('DOMContentLoaded', async () => {
  console.log('cart.js loaded');
  const cartEl = document.getElementById('cartItems');
  let cart = [];

  async function fetchCart() {
    const res = await fetch('/api/v1/cart/view');
    cart = await res.json();
    renderCart();
  }

  function renderCart() {
    if (!cart || cart.length === 0) {
      cartEl.innerHTML = '<div class="alert alert-warning">Cart is empty. <a href="/trucks">Browse trucks</a></div>';
      return;
    }
    let total = 0;
    cartEl.innerHTML = `
      <table class="table">
        <thead><tr><th>Item</th><th>Price</th><th>Qty</th><th>Subtotal</th><th></th></tr></thead>
        <tbody>
          ${cart.map(i => {
            const sub = i.price * i.quantity;
            total += sub;
            return `<tr>
              <td>${i.itemName}</td>
              <td>$${i.price}</td>
              <td>
                <button class="btn btn-sm btn-secondary qty-btn" data-id="${i.cartId}" data-delta="-1">-</button>
                <span class="mx-2">${i.quantity}</span>
                <button class="btn btn-sm btn-secondary qty-btn" data-id="${i.cartId}" data-delta="1">+</button>
              </td>
              <td>$${sub.toFixed(2)}</td>
              <td><button class="btn btn-danger btn-sm remove-btn" data-id="${i.cartId}">Remove</button></td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
      <div class="mb-3"><strong>Total: $${total.toFixed(2)}</strong></div>
      <button class="btn btn-success" id="placeOrderBtn">Place Order</button>
    `;
  }

  cartEl.addEventListener('click', async (e) => {
    if (e.target.classList.contains('qty-btn')) {
      const cartId = e.target.getAttribute('data-id');
      const delta = parseInt(e.target.getAttribute('data-delta'), 10);
      const item = cart.find(i => i.cartId == cartId);
      if (!item) return;
      const newQty = item.quantity + delta;
      if (newQty < 1) return;
      await fetch(`/api/v1/cart/edit/${cartId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ quantity: newQty })
      });
      await fetchCart();
    }
    if (e.target.classList.contains('remove-btn')) {
      const cartId = e.target.getAttribute('data-id');
      await fetch(`/api/v1/cart/delete/${cartId}`, { method: 'DELETE' });
      await fetchCart();
    }
    if (e.target.id === 'placeOrderBtn') {
      // Simple place order
      const res = await fetch('/api/v1/order/new', { method: 'POST' });
      if (res.ok) {
          // Trigger confetti animation
          document.dispatchEvent(new Event('orderPlaced'));
        cartEl.innerHTML = '<div class="alert alert-success">Order placed! <a href="/myOrders">View Orders</a></div>';
      } else {
        alert('Failed to place order');
      }
    }
  });

  fetchCart();
});