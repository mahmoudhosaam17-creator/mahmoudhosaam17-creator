// Owner dashboard logic with modern light switch toggle
document.addEventListener('DOMContentLoaded', async () => {
	const truckName = document.getElementById('truckName');
	const truckStatus = document.getElementById('truckStatus');
	const statMenuItems = document.getElementById('statMenuItems');
	const statPending = document.getElementById('statPending');
	const orderStatusToggle = document.getElementById('orderStatusToggle');
	const orderStatusLabel = document.getElementById('orderStatusLabel');

	// Modern light switch styling
	orderStatusToggle.classList.add('form-check-input');
	orderStatusToggle.style.width = '48px';
	orderStatusToggle.style.height = '24px';
	orderStatusToggle.style.cursor = 'pointer';
	orderStatusToggle.style.accentColor = '#0d6efd';
	orderStatusToggle.style.boxShadow = '0 0 0 2px #e0e0e0';

	function setSwitchUI(isOpen) {
		orderStatusToggle.checked = isOpen;
		orderStatusLabel.innerHTML = isOpen
			? '<span class="badge bg-success ms-2">Open</span>'
			: '<span class="badge bg-danger ms-2">Closed</span>';
		orderStatusToggle.setAttribute('aria-checked', isOpen);
		// Update status box beside truck name
		const statusBox = document.getElementById('truckStatusBox');
		if (statusBox) {
			if (isOpen) {
				statusBox.textContent = 'Available';
				statusBox.classList.add('status-available');
				statusBox.classList.remove('status-unavailable');
			} else {
				statusBox.textContent = 'Not Available';
				statusBox.classList.add('status-unavailable');
				statusBox.classList.remove('status-available');
			}
		}
	}

	async function fetchDashboard() {
		const res = await fetch('/api/v1/owner/dashboard');
		const data = await res.json();
		truckName.textContent = data.truckName;
		// Remove old status badge logic
		statMenuItems.textContent = data.menuItems;
		statPending.textContent = data.pendingOrders;
		setSwitchUI(data.orderOpen);
	}

	orderStatusToggle.addEventListener('change', async () => {
		const isOpen = orderStatusToggle.checked;
		setSwitchUI(isOpen);
		await fetch('/api/v1/owner/order-availability', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ open: isOpen })
		});
	});

	await fetchDashboard();
});