// Protected view routes placeholder
const express = require('express');
const router = express.Router();

router.get('/dashboard', (req, res) => res.send('Protected dashboard view'));

module.exports = router;
