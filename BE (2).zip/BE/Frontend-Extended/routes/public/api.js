const router = require('express').Router();
const db = require('../../connectors/db');

router.get('/api/v1/trucks/view', async (req, res) => {
  try {
    const trucks = await db('FoodTruck.Trucks')
      .where({ truckStatus: 'available' });

    res.json(trucks);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch trucks' });
  }
});

app.get('/api/v1/trucks/view', async (req, res) => {
  try {
    const trucks = await db('Trucks')
      .where({ truckStatus: 'available' })
      .select(
        'truckId',
        'truckName',
        'truckLogo',
        'truckStatus'
      );

    return res.status(200).json(trucks);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Failed to load trucks' });
  }
});



// GET /api/v1/menuItem/truck/:truckId
router.get('/api/v1/menuItem/truck/:truckId', async (req, res) => {
  try {
    const truckId = req.params.truckId;
    const menuItems = await db('FoodTruck.MenuItems')
      .where({ truckId })
      .select('itemId', 'name', 'description', 'price', 'category', 'status')
      .orderBy('itemId', 'asc');
    return res.status(200).json(menuItems);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Failed to load menu' });
  }
});

module.exports = router;