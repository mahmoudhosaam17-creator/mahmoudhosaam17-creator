
const knex = require('knex');
require('dotenv').config();

const config = {
  client: 'pg',
  connection: {
    host : 'localhost',
    port : 5432,
    user : 'postgres',
    password : process.env.PASSWORD,
    database : 'FoodTruck'
  }
};

const db = knex(config);
module.exports = db;
