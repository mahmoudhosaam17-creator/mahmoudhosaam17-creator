// Authentication middleware placeholder
module.exports = function auth(req, res, next) {
  // TODO: verify session / token and attach user to req
  next();
};
