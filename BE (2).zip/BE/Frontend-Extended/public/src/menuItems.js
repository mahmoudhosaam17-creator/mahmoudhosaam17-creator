

async function loadMenu(truckId, gridId) {
	const menuEl = document.getElementById(gridId);
	if (!menuEl) return;
	menuEl.innerHTML = 'Loading menu...';
	try {
		const res = await fetch(`http://localhost:3000/api/v1/menuItem/truck/${truckId}`);
		if (!res.ok) throw new Error('Failed to load menu');
		const items = await res.json();
		if (!items.length) {
			menuEl.innerHTML = '<div class="alert alert-warning">No menu items available.</div>';
			return;
		}
		menuEl.innerHTML = items.map(i => `
			<div class="menu-card">
				<div class="menu-img">🍔</div>
				<div class="menu-name">${i.name}</div>
				<div class="menu-desc">${i.description || ''}</div>
				<div class="menu-price">$${i.price}</div>
			</div>
		`).join('');
	} catch (err) {
		menuEl.innerHTML = `<div class="alert alert-danger">Could not load menu. ${err.message}</div>`;
	}
}

document.addEventListener('DOMContentLoaded', () => {
	loadMenu(1, 'menuItemsGrid-1'); // Burger Paradise
	loadMenu(2, 'menuItemsGrid-2'); // Tacos
});
