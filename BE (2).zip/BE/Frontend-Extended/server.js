// Minimal server placeholder for Frontend-Extended
const express = require('express');
const app = express();

app.get('/', (req, res) => res.send('Frontend-Extended server placeholder'));

if (require.main === module) {
  const port = process.env.PORT || 3001;
  app.listen(port, () => console.log(`Server running on http://localhost:${port}`));
}
const publicApi = require('./routes/public/api');
const publicView = require('./routes/public/view');
const privateApi = require('./routes/private/api');
const privateView = require('./routes/private/view');

app.use(express.static('public'));

app.use(publicApi);

app.use(publicView);
app.use(privateApi);
app.use(privateView);

module.exports = app;


