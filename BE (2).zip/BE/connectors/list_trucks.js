const db = require('./db');

(async () => {
  try {
    const trucks = await db('FoodTruck.Trucks').select('*');
    console.log('Food Trucks:', trucks);
    process.exit(0);
  } catch (err) {
    console.error('Error querying trucks:', err);
    process.exit(1);
  }
})();
