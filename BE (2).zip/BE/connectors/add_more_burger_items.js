const db = require('./db');

(async () => {
  try {
    // Add more menu items for Burger Paradise (truckId: 2)
    await db('FoodTruck.MenuItems').insert([
      {
        truckId: 2,
        name: 'Veggie Burger',
        description: 'A delicious vegetarian burger with fresh veggies',
        price: 38.00,
        category: 'Main Course',
        status: 'available'
      },
      {
        truckId: 2,
        name: 'Spicy Chicken Burger',
        description: 'Crispy chicken burger with spicy sauce',
        price: 40.00,
        category: 'Main Course',
        status: 'available'
      },
      {
        truckId: 2,
        name: 'Onion Rings',
        description: 'Crispy fried onion rings',
        price: 15.00,
        category: 'Sides',
        status: 'available'
      },
      {
        truckId: 2,
        name: 'Soft Drink',
        description: 'Cold refreshing drink',
        price: 10.00,
        category: 'Beverages',
        status: 'available'
      }
    ]);
    console.log('Added more menu items for Burger Paradise.');
    process.exit(0);
  } catch (err) {
    console.error('Error adding menu items:', err);
    process.exit(1);
  }
})();
